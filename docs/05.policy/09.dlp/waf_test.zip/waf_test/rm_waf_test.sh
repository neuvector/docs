kubectl delete -f waf_group_httpd.yml
kubectl delete -f waf_traversal.yml
kubectl delete -f waf_injection.yml
kubectl delete -f waf_cross.yml
kubectl delete -f waf_execution.yml
kubectl delete -f http_backend.yaml
