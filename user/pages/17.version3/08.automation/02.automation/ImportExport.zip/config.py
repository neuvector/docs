#!/usr/bin/python

import argparse
import io
import json
import sys
import zlib

import client
import multipart

def _write_part(part, filename):
    if filename and len(filename) > 0:
        try:
            with open(filename, 'w') as wfp:
                wfp.write(part.raw)
            print("Wrote configurations to %s" % filename)
            return 0
        except IOError:
            print("Error: Failed to write configurations to %s" % filename)
            return -1
    else:
        # gzip
        cfg = zlib.decompress(part.raw, 16+zlib.MAX_WBITS)
        print(cfg)
        return 0

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Import/export configuration')
    parser.add_argument('action', choices=['import', 'export'])
    parser.add_argument('-d', '--debug', action="store_true", help='Enable debug')
    parser.add_argument('-s', '--server', default="127.0.0.1", help='Controller IP address.')
    parser.add_argument('-p', '--port', type=int, default=443, help='Controller port.')
    parser.add_argument('-u', '--username', default="admin", help='Username')
    parser.add_argument('-w', '--password', default="admin", help='Password')
    parser.add_argument('-f', '--filename', help='Filename')
    parser.add_argument('--section', nargs='*', help='Export sections')

    args = parser.parse_args()

    ret = 1

    # import pdb; pdb.set_trace()
    url = "https://%s:%s" % (args.server, args.port)
    c = client.RestClient(url, args.debug)

    try:
        token = c.login(args.username, args.password)
    except client.RestException as e:
        print("Error: " + e.msg)
        sys.exit(ret)

    if args.action == "export":
        # export
        if args.section and len(args.section) > 0:
            secs = ','.join(args.section)
            headers, body = c.download("file/config?section=" + secs)
        else:
            headers, body = c.download("file/config")

        kwargs = {'strict': True}
        clen = int(headers.get('Content-Length', '-1'))
        ctype, options = multipart.parse_options_header(headers.get("Content-Type"))
        boundary = options.get('boundary','')
        if ctype != 'multipart/form-data' or not boundary:
            print("Error: Unsupported content type.")
        else:
            try:
                found = False
                for part in multipart.MultipartParser(io.BytesIO(body.content), boundary, clen):
                    if part.name == "configuration" and part.content_type == "application/x-gzip":
                        found = True
                        ret = _write_part(part, args.filename)

                if not found:
                    print("Error: Unable to export configurations.")
            except Exception as e:
                print(e)
    elif args.action == "import":
        # import
        if not args.filename:
            print("Error: Import filename is not specified.")
        else:
            try:
                c.upload("file/config", args.filename)

                ret = 0
                print("Uploaded configuration file %s" % args.filename)
            except IOError:
                print("Error: Failed to upload configuration file %s" % args.filename)
    else:
        print("Error: Unsupported action.")

    try:
        c.logout()
    except client.RestException:
        pass

    sys.exit(ret)
